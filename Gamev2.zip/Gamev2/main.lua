local state = 0 --Global state of the game


require "characters_controllers/swordsman"




function love.load()

	flags = {}
	flags["fullscreen"] = false
	flags["centered"] = true
	love.window.setMode(1280, 720, flags)
	screen_width = love.graphics.getWidth()
	screen_height = love.graphics.getHeight()

	cellSize = 80
	minCellX = 0
	minCellY = 0
	maxCellX = (1280/cellSize)-1
	maxCellY = (720/cellSize)-1

	char = generateSwordsman(0,0)

	enemy = {

		currentPos = {x = maxCellX, y = maxCellY},

		startTurn = function(self)
			love.keypressed = nil
			self.currentPos.x = self.currentPos.x - 1
			return self:endTurn();
		end,

		endTurn = function(self)
			return nextTurn()
		end
	}

	turns = {char,enemy}

	turn = 2

	nextTurn()

end

function love.draw()
	love.graphics.setColor(0, 100, 100)
    love.graphics.rectangle("fill", char.currentPos.x * cellSize, char.currentPos.y * cellSize, cellSize, cellSize)

	love.graphics.setColor(0, 1, 0, 1)
	love.graphics.rectangle("fill", enemy.currentPos.x * cellSize, enemy.currentPos.y * cellSize, cellSize, cellSize)
end

function love.update(dt)
end
 

function nextTurn()
	nextTurnChar = turns[(turn%2)+1]
	turn = turn +1
	return nextTurnChar:startTurn()
end
